<?php

namespace Maatwebsite\Excel\Concerns;

interface WithProperties
{
    public function properties(): array;
}
